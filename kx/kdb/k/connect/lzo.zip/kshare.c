/* kshare.c -- k interface for the miniLZO library

   This file is based on testmini.c, which is part of the LZO
   real-time data compression library.

   Copyright (C) 2001 Kx Systems, Inc.
   Copyright (C) 1996-2000 Markus Franz Xaver Johannes Oberhumer

   The LZO library is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of
   the License, or (at your option) any later version.

   The LZO library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with the LZO library; see the file COPYING.
   If not, write to the Free Software Foundation, Inc.,
   59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   Markus F.X.J. Oberhumer
   markus.oberhumer@jk.uni-linz.ac.at
 */


#include <stdio.h>
#include <stdlib.h>

#include "minilzo.h"
#include "c:/c/k20x.h"


/* Work-memory needed for compression. Allocate memory in units
 * of `long' (instead of `char') to make sure it is properly aligned.
 */

#define HEAP_ALLOC(var,size) \
	long __LZO_MMODEL var [ ((size) + (sizeof(long) - 1)) / sizeof(long) ]

static HEAP_ALLOC(wrkmem,LZO1X_1_MEM_COMPRESS);

static int init;

/*************************************************************************
//
**************************************************************************/

static int kinit(void)
{
/*
	fprintf(stderr, "\nLZO real-time data compression library (v%s, %s).\n",
	        lzo_version_string(), lzo_version_date());
	fprintf(stderr, "Copyright (C) 2001 Kx Systems, Inc.\n");
	fprintf(stderr, "Copyright (C) 1996-2000 "
            "Markus Franz Xaver Johannes Oberhumer\n\n");
*/


/*
 * Initialize the LZO library
 */
	if (lzo_init() != LZO_E_OK)
	{
/*
		fprintf(stderr, "lzo_init() failed !!!\n");
*/
		return 1;
	}
	return 0;
}

K lzoc(K in)
{
	int r;
	lzo_uint out_len;
	K out;
	int db = 0;

	if(!init)if(init=!init,kinit())return kerr("LZO init");

	/* if in is not a byte vector, make it one. */
	if (in->t != -3)
	{
		K obj;
		db = 0x80;
		in = ksk("_bd", obj=gnk(1,ci(in)));
		cd(obj);
		if(in->t==6)return cd(in),kerr((S)in->n);
	}

	out_len = in->n + in->n / 64 + 16 + 3;
	out = gtn(-3,4+out_len);

	/* return value will be a byte vector, with the first four bytes being
	   the length of the original data in big endian. */
	r = lzo1x_1_compress(KC(in),in->n,KC(out)+4,&out_len,wrkmem);
	if (r != LZO_E_OK)
	{
		/* this should NEVER happen */
		return kerr("compression");
	}
/*
	fprintf(stderr, "compressed %lu bytes into %lu bytes\n",
		(long) in->n, (long) out_len);
*/
	out->n=4+out_len;
	KC(out)[0]=db|(in->n>>24);
	KC(out)[1]=(in->n>>16)&0xff;
	KC(out)[2]=(in->n>>8)&0xff;
	KC(out)[3]=in->n&0xff;

	return out;
}

K lzod(K in)
{
	int r;
	lzo_uint orig_len;
	lzo_uint out_len;
	K out;

	if(!init)if(init=!init,kinit())return kerr("LZO init");

	/* in must be a byte vector with the first four bytes being the length
	   of the original data in big endian. */
	if (in->t != -3)
		return kerr("type");

	orig_len=((0x7f&KC(in)[0])<<24)|(KC(in)[1]<<16)|(KC(in)[2]<<8)|KC(in)[3];
	out = gtn(-3,orig_len);

	r = lzo1x_decompress(KC(in)+4,in->n-4,KC(out),&out_len,NULL);
	if (r != LZO_E_OK || out_len != orig_len)
	{
		/* this should NEVER happen */
		return kerr("decompression");
	}
/*
	fprintf(stderr, "decompressed %lu bytes back into %lu bytes\n",
		(long) in->n-4, (long) orig_len);
*/
	if (KC(in)[0]&0x80)
	{
		K obj;
		out = ksk("_db", obj=gnk(1,ci(out)));
		cd(obj);
	}

	return out;
}

# if running the kdb+tick example, change these to full paths
# some of the kdb+tick processes will change directory, and these will no longer be valid
export KDBCONFIG=./config
export KDBCODE=./code
export KDBLOG=./logs
export KDBHTML=./html

"""python interface to k

Modules:

K - defines K object in python
ksql - ksql support functions

_k20 - low level interface to libk20
_nk20 - low level support for Numeric 

"""
